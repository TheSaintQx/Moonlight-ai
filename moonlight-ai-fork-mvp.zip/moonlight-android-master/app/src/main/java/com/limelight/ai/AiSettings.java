package com.limelight.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/** Preferences for the optional AI assistant. No model-provider API key belongs in the APK. */
public final class AiSettings {
    public static final String ENABLED = "ai_assistant_enabled";
    public static final String BASE_URL = "ai_assistant_base_url";
    public static final String DEVICE_TOKEN = "ai_assistant_device_token";

    private AiSettings() {}

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(ENABLED, false);
    }

    public static String getBaseUrl(Context context) {
        return prefs(context).getString(BASE_URL, "").trim();
    }

    public static String getDeviceToken(Context context) {
        return prefs(context).getString(DEVICE_TOKEN, "").trim();
    }

    private static SharedPreferences prefs(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
    }
}
