package com.limelight.ai;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Minimal asynchronous client for the user's own AI backend. It never calls Gemini directly. */
public final class AiApiClient {
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .build();

    public interface ResultCallback {
        void onSuccess(String reply);
        void onFailure(String message);
    }

    private AiApiClient() {}

    public static void testConnection(String baseUrl, String deviceToken, ResultCallback callback) {
        String normalized = baseUrl == null ? "" : baseUrl.trim().replaceAll("/+$", "");
        if (!normalized.startsWith("https://")) {
            callback.onFailure("Укажи HTTPS-адрес своего AI-сервера.");
            return;
        }

        JSONObject payload = new JSONObject();
        try {
            payload.put("message", "Ответь одним коротким предложением: сервер игрового помощника работает.");
            JSONObject context = new JSONObject();
            context.put("source", "moonlight-android");
            context.put("purpose", "connection_test");
            payload.put("context", context);
        } catch (JSONException e) {
            callback.onFailure("Не удалось подготовить тестовый запрос.");
            return;
        }

        Request.Builder request = new Request.Builder()
                .url(normalized + "/v1/assistant/chat")
                .post(RequestBody.create(payload.toString(), JSON))
                .header("Accept", "application/json");
        if (deviceToken != null && !deviceToken.trim().isEmpty()) {
            request.header("Authorization", "Bearer " + deviceToken.trim());
        }

        HTTP.newCall(request.build()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onFailure("Не удалось подключиться к AI-серверу: " + safeMessage(e));
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (Response res = response) {
                    if (!res.isSuccessful()) {
                        callback.onFailure("AI-сервер вернул HTTP " + res.code() + ". Проверь адрес, токен и API.");
                        return;
                    }
                    if (res.body() == null) {
                        callback.onFailure("AI-сервер вернул пустой ответ.");
                        return;
                    }
                    JSONObject body = new JSONObject(res.body().string());
                    String reply = body.optString("reply", "").trim();
                    if (reply.isEmpty()) {
                        callback.onFailure("В ответе сервера нет непустого поля 'reply'.");
                    } else {
                        callback.onSuccess(reply);
                    }
                } catch (IOException | JSONException e) {
                    callback.onFailure("Не удалось прочитать ответ AI-сервера.");
                }
            }
        });
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }
}
