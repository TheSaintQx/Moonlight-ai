# Experimental backend

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

By default `AI_PROVIDER=stub`, so `GET /health` and the chat endpoint can be tested without a Gemini key. The Android app intentionally accepts HTTPS URLs only; put this service behind a trusted HTTPS reverse proxy for device testing. For local testing only, you can use a development build/configuration that permits your own local HTTP endpoint, but do not expose it or send secrets over plain HTTP.

Set `MOONLIGHT_DEVICE_TOKEN` to require a bearer token on `/v1/assistant/chat`. Store the same value in Moonlight's **Device access token** setting. If unset, authentication is disabled and the service must not be exposed publicly.

## Gemini

Set `AI_PROVIDER=gemini` and `GEMINI_API_KEY` only if Google permits your account/project and region to use the Gemini API. This code calls Google's official API endpoint directly; it does not attempt to circumvent regional restrictions. Provider failures are returned as a generic gateway error.

## Alice skill

Configure `/alice/webhook` as the HTTPS webhook URL for a test skill in Yandex Dialogs. This is only a development scaffold: before production, implement Yandex's current request authenticity/signature validation, rate limiting, privacy disclosures, and robust session handling. The webhook and Android endpoint currently share the provider logic but do not yet share a paired game's live context.
