"""Experimental Moonlight AI backend and Alice webhook scaffold.

Default provider is a local stub so the integration can be tested without Gemini.
Set AI_PROVIDER=gemini only after verifying Gemini API availability and terms for your region.
"""
import os
import secrets
from typing import Any

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field

app = FastAPI(title="Moonlight AI Assistant", version="0.1.0")
DEVICE_TOKEN = os.getenv("MOONLIGHT_DEVICE_TOKEN", "")
AI_PROVIDER = os.getenv("AI_PROVIDER", "stub").lower()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    context: dict[str, Any] = Field(default_factory=dict)


class ChatResponse(BaseModel):
    reply: str


def check_token(authorization: str | None) -> None:
    # For local experiments, no configured token means auth is disabled. Set a token before
    # exposing this service to the Internet.
    if not DEVICE_TOKEN:
        return
    expected = f"Bearer {DEVICE_TOKEN}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="unauthorized")


async def get_reply(message: str, context: dict[str, Any] | None = None) -> str:
    if AI_PROVIDER == "stub":
        return ("Тестовый помощник получил вопрос. Подключение работает; для игровых подсказок "
                "настрой разрешённый AI-провайдер.")

    if AI_PROVIDER != "gemini":
        raise HTTPException(status_code=503, detail="unsupported_provider")
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=503, detail="gemini_key_not_configured")

    # Direct official API endpoint only. This does not attempt to bypass regional restrictions.
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    prompt = "Ты краткий игровой помощник. Отвечай по-русски, практично и коротко.\n"
    if context:
        prompt += f"Контекст игры (может быть неполным): {context}\n"
    prompt += f"Вопрос игрока: {message}"
    async with httpx.AsyncClient(timeout=25.0) as client:
        response = await client.post(
            url,
            params={"key": GEMINI_API_KEY},
            json={"contents": [{"parts": [{"text": prompt}]}]},
        )
    if response.status_code >= 400:
        # Do not return provider response bodies: they may contain internal details.
        raise HTTPException(status_code=502, detail=f"gemini_provider_error_{response.status_code}")
    try:
        data = response.json()
        reply = data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (KeyError, IndexError, TypeError, ValueError):
        raise HTTPException(status_code=502, detail="invalid_provider_response")
    return reply[:3000] or "Не удалось сформировать ответ. Попробуй ещё раз."


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "provider": AI_PROVIDER}


@app.post("/v1/assistant/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest, authorization: str | None = Header(default=None)) -> ChatResponse:
    check_token(authorization)
    return ChatResponse(reply=await get_reply(payload.message, payload.context))


@app.post("/alice/webhook")
async def alice_webhook(request: Request) -> dict[str, Any]:
    """Minimal Alice skill response format. Add Yandex request-signature validation before prod."""
    body = await request.json()
    command = str((body.get("request") or {}).get("command") or "").strip()
    if not command:
        reply = "Привет! Задай вопрос об игре, и я постараюсь помочь."
    else:
        try:
            reply = await get_reply(command, {"source": "alice_skill"})
        except HTTPException:
            reply = "Сейчас игровой помощник недоступен. Попробуй немного позже."
    # Alice responses should be short; this keeps the voice output manageable.
    reply = reply[:700]
    session = body.get("session") or {}
    return {
        "version": body.get("version", "1.0"),
        "session": session,
        "response": {"text": reply, "end_session": False},
    }
