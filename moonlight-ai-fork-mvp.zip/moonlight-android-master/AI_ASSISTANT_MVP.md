# Moonlight AI Assistant MVP

This is an experimental scaffold. It deliberately does not modify Moonlight's streaming, video decoding, or gamepad input code.

## Android changes

The Settings screen has an **AI Game Assistant (experimental)** section:

- Enable AI assistant integration (configuration flag for future UI/flows).
- AI backend URL (HTTPS only).
- Optional device bearer token.
- Test AI backend (sends one request asynchronously).

The Android client never calls Gemini directly and must never contain a Gemini API key.

## Backend API contract

`POST /v1/assistant/chat`

Request:

```json
{
  "message": "Ответь одним коротким предложением: сервер игрового помощника работает.",
  "context": {
    "source": "moonlight-android",
    "purpose": "connection_test"
  }
}
```

Optional header: `Authorization: Bearer <device-token>`.

Successful response (`HTTP 200`):

```json
{ "reply": "Игровой помощник готов к работе." }
```

Errors should use a non-2xx HTTP status and a JSON body, e.g. `{"error":"unauthorized"}`. Keep responses short for speech synthesis. Use HTTPS with a valid certificate. Never log authorization tokens or secrets.

## Alice skill integration

Implement the Alice skill as a separate HTTPS webhook service. It should validate requests according to current Yandex Dialogs documentation, extract the user's text, call the same assistant service, and return a short text response in the Alice response format. Do not assume the Alice skill can directly inspect Moonlight or listen in the background while another app is running. Linking game context requires explicit pairing and a separate authenticated context API in a later iteration.

## Gemini and regional availability

Configure the Gemini key only as a server-side secret (environment/secret manager). Do not route traffic through infrastructure to evade a regional restriction. Before enabling the Gemini provider, verify that the account, project, region, and intended use are eligible under current Google terms. Keep provider selection pluggable so a permitted alternative can be used.

## Current limitation

The Android-side settings and test client are included; this archive does not yet include a deployed backend or a registered Alice skill. The test button will only succeed once an HTTPS backend implementing the contract above is available.
